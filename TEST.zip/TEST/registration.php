
           
            <div class="modal-body">
                 <form  action="register.php"  method="post">
                    <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                      <input id="name" type="text" class="form-control" name="name" placeholder="Full Name">
                     </div>
                      <br/>
                    <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
                      <input id="mobile" type="text" class="form-control" name="mobile" placeholder="Mobile">
                      </div>
                      <br/>
                    <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                      <input id="email" type="email" class="form-control" name="email" placeholder="Email">
                    </div>
                    <br/>
                    <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                      <input id="password" type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    <br>
                    <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                      <input id="cpassword" type="password" class="form-control" name="cpassword" placeholder="Confirm Password">
                    </div>
                    <br>
                     <div >
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="register" class="btn btn-primary"> Save </button>
                    </div>
                </form>
            </div>

